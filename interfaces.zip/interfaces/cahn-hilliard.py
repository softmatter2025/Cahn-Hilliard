import numpy as np
import scipy
import matplotlib.pyplot as plt
import os
from tqdm import tqdm


def save_grid(path, kx, ky, Nx, Ny):
    # Open the file for writing
    with open(path, "w") as f:
        f.write("BOX:\n")
        f.write(f"{kx.min()} {kx.max()}\n")
        f.write(f"{ky.min()} {ky.max()}\n")
        f.write(f"{0} {0}\n")

        f.write("SHAPE:\n")
        f.write(f"{Nx} {Ny} {0}\n")

        f.write("COORDINATES: X Y Z\n")

        # Create coordinate arrays for X, Y, and Z
        X_coords = kx.flatten()
        Y_coords = ky.flatten()
        Z_coords = np.zeros_like(X_coords)  # You can adjust Z_coords as needed

        # Combine coordinates into a single array
        coordinates = np.column_stack((X_coords, Y_coords, Z_coords))

        # Write coordinates to the file
        np.savetxt(f, coordinates, fmt="%.4f %.4f %.4f")
    
def save_field(path, v, n, t):
    # Open the file for writing
    with open(path, "w") as f:
        # Write simulation time
        f.write("TIMESTEP:\n")
        f.write(f"{n}\n")
        
        # Write time
        f.write("TIME:\n")
        f.write(f"{t}\n")

        # Write field names
        field_names = ["c"]
        f.write("DATA: " + " ".join(field_names) + "\n")

        # Write field values       
        np.savetxt(f, v.flatten(), fmt="%.16f")


# Code to simulate the 2D Cahn-Hilliard equation, and save the results as images

# Parameters
# N = 2 * 128
# L = 2 * 32 * np.pi
Nx = 8192
Ny = 1
L = (Nx/32) * 2 * np.pi
dt = 0.2
steps = 100000
write_every = steps
plt_aft = 20000
asym_coeff = 0


# Nx = 4096
# Ny = 1
# L = (Nx/128) * 2 * np.pi
# dt = 0.05
# steps = 500*2*2
# write_every=500
# plt_aft = 100
# asym_coeff = 0.

for alpha in [0, -0.1]:
    alpha=float(alpha)
    kappa = 1
    b = 1
    a = alpha*b

    # Create a folder to save figures
    simname=f"{alpha:05.4}"
    fig_folder = "output_figures_"+simname
    os.makedirs(fig_folder, exist_ok=True)
    data_folder = "output_data_"+simname
    os.makedirs(data_folder, exist_ok=True)

    # Initial state
    v = -np.ones((Ny, Nx))
    v[:,int(Nx/2):]=1
    v_hat = scipy.fft.fft2(v, workers=-1)

    # save grid for AMEP
    # save_grid(os.path.join(data_folder,"grid.txt"), kx, ky, N)
    x,y = np.meshgrid(np.linspace(0,L,Nx), np.linspace(0,L,Ny))
    save_grid(os.path.join(data_folder,"grid.txt"), x,y, Nx,Ny)

    # save initial conditions
    save_field(os.path.join(data_folder, f"field_{0}.txt"), v, 0, 0)

    # plot initial conditions
    plt.pcolormesh(v)
    plt.colorbar()
    plt.title(f"Time {0}")
    # Save the figure in the specified folder
    figure_path = os.path.join(fig_folder, f"timestep_{0}.png")
    plt.savefig(figure_path, dpi=300)
    plt.close()  # Close the figure to avoid displaying it

    # Grid
    kx = (2 * np.pi / L) * np.arange(-Nx / 2, (Nx / 2))
    ky = (2 * np.pi / L) * np.arange(-Ny / 2, (Ny / 2))
    kx, ky = np.meshgrid(kx, ky)
    kx = scipy.fft.ifftshift(kx)
    ky = scipy.fft.ifftshift(ky)
    k2x = kx ** 2
    k2y = ky ** 2
    k2 = k2x + k2y
    k4 = k2 ** 2

    # # save grid for AMEP
    # save_grid(os.path.join(data_folder,"grid.txt"), kx, ky, Ny, Nx)

    # # save initial conditions
    # save_field(os.path.join(data_folder, f"field_{0}.txt"), v, 0, 0)

    # # plot initial conditions
    # plt.pcolormesh(v)
    # plt.colorbar()
    # plt.title(f"Time {0}")
    # # Save the figure in the specified folder
    # figure_path = os.path.join(fig_folder, f"timestep_{0}.png")
    # plt.savefig(figure_path, dpi=300)
    # plt.close()  # Close the figure to avoid displaying it

    # Implicit time-stepping (backward Euler)
    for n in tqdm(range(1, steps + 1), desc="Simulating", unit="steps"):
        # scipy multi-processing
        v3_hat = scipy.fft.fft2(v ** 3, workers=-1)

        v_hat = (v_hat / dt - b*k2*v3_hat) / (1 / dt + a*k2 + kappa*k4)
        v = np.real(scipy.fft.ifft2(v_hat, workers=-1))

        if (n%write_every == 0):
            save_field(os.path.join(data_folder, f"field_{n}.txt"), v, n, n*dt)

        if n % plt_aft == 0:
            plt.pcolormesh(v)
            plt.colorbar()
            plt.title(f"Time {n*dt}")

            # Save the figure in the specified folder
            figure_path = os.path.join(fig_folder, f"timestep_{n}.png")
            plt.savefig(figure_path, dpi=300)
            plt.close()  # Close the figure to avoid displaying it
            
    # Optional: Display a message when the process is complete
    print(f"Figures saved in '{fig_folder}' folder.")
